# @authplatform/auth-react

Accessible client components and hooks for Auth Platform.

```tsx
"use client";
import { AuthProvider, SignIn } from "@authplatform/auth-react";
import "@authplatform/auth-react/styles.css";

export default function LoginPage() {
  return <AuthProvider><SignIn /></AuthProvider>;
}
```

The provider communicates only with the mounted Next.js BFF at `/api/auth`. It never reads an access or refresh token.
