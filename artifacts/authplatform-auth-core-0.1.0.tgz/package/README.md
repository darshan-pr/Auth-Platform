# @authplatform/auth-core

Framework-agnostic Auth Platform client. It talks to a relative BFF path by default and never stores or exposes access/refresh tokens.

```ts
import { AuthClient } from "@authplatform/auth-core";

const auth = new AuthClient();
await auth.signIn({ email, password });
const user = await auth.getUser();
```

The browser must mount the Next.js BFF from `@authplatform/auth-nextjs`; direct browser calls to Spring Boot are intentionally unsupported.
